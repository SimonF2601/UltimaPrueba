package com.riwi.performance_test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PerformanceTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
